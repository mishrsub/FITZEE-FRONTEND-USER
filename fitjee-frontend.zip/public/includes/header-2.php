<header class="theme-menu-wrapper menu-style-two">
				<div class="top-header">
					<div class="container">
						<ul class="float-left left-content">
							<li><i class="flaticon-phone-call"></i> <a href="#">08080220888</a></li>
							<li><i class="flaticon-envelope"></i> <a href="#">helpdesk@myfiitjee.com</a></li>
							<li>
								<div class="bfh-selectbox bfh-languages" data-language="en_US" data-available="en_US,fr_CA,es_MX" data-flags="true"></div>
							</li>
						</ul>
						<ul class="float-right right-content">
							<li><a href="#" class="tran3s social"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li><a href="#" class="tran3s social"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li><a href="#" class="tran3s social"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
							<li><a href="#" class="tran3s social"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
						</ul>
					</div> <!-- /.container -->
				</div> <!-- /.top-header -->
				<div class="container">
					<div class="header-wrapper clearfix">
						<!-- Logo -->
						<div class="logo float-left tran4s hidden-sm hidden-xs"><a href="index.php"><img src="images/logo/logo5.png" alt="Logo" style="width: 130px;"></a></div>
						<!-- Logo -->
						<div class="logo float-left tran4s hidden-md hidden-lg"><a href="index.php"><img src="images/logo/logo5.png" alt="Logo" style="width: 130px;"></a></div>

						<div class="float-right header-widget">
						   <!-- Curt Button -->
							<!-- <button class="tran3s login float-right login" data-toggle="modal" data-target=".signInModal"><i class="flaticon-lock"></i> Login</button> -->
						</div>

						<!-- ============================ Theme Menu ========================= -->
						<nav class="theme-main-menu float-right navbar" id="mega-menu-wrapper">
							<!-- Brand and toggle get grouped for better mobile display -->
						   <div class="navbar-header">
						     <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse-1" aria-expanded="false">
						       <span class="sr-only">Toggle navigation</span>
						       <span class="icon-bar"></span>
						       <span class="icon-bar"></span>
						       <span class="icon-bar"></span>
						     </button>
						   </div>
						   <!-- Collect the nav links, forms, and other content for toggling -->
						   <div class="collapse navbar-collapse" id="navbar-collapse-1">
								<ul class="nav">
									<li><a href="index.php" class="tran3s">Home</a>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">About</a>
										<ul class="sub-menu">
											<li><a href="javascript:void(0);">About us</a></li>
											<li><a href="javascript:void(0);">Mission and Vision</a></li>
											<li><a href="javascript:void(0);">Chairman's Message</a></li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Programs</a>
										<ul class="sub-menu">
											<li class="dropdown-holder"><a href="course.php">Class VI</a>
												<ul class="second-sub-menu">
													<li class="dropdown-holder"><a href="#">Offline Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">Math Genie</a></li>
															<li><a href="#">Little Genie One Year Foundation Program (N)</a></li>
														</ul>
													</li>
													<li class="dropdown-holder"><a href="#">Digital Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">e-LITTLE GENIE little Genie-One Year Live Online Foundation Program</a></li>
															<li><a href="#">e-Maths Genie</a></li>
														</ul>
													</li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class VII</a>
												<ul class="second-sub-menu">
													<li class="dropdown-holder"><a href="#">Offline Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">UDAYA-Two Year Classroom Program- Weekend Contact Classes</a></li>
														</ul>
													</li>
													<li class="dropdown-holder"><a href="#">Digital Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">e-UDAYA - Two Year Live Online Classroom Program</a></li>
															<li><a href="#">e-Maths Genie</a></li>
														</ul>
													</li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class VIII</a>
												<ul class="second-sub-menu">
													<li class="dropdown-holder"><a href="#">Offline Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">UDAYA-One Year Classroom Program- Weekend Contact Classes (8052</a></li>
														</ul>
													</li>
													<li class="dropdown-holder"><a href="#">Digital Classroom Programs</a>
														<ul class="third-sub-menu">
															<li><a href="#">e-UDAYA - One Year Live Online Classroom Program</a></li>
														</ul>
													</li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class IX</a>
												<ul class="second-sub-menu">
													<li><a href="#">Offline Classroom Programs</a></li>
													<li><a href="#">Digital Classroom Programs</a></li>
													<li><a href="#">Non-Classroom Programs</a></li>
													<li><a href="#">Integrated School Programs</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class X</a>
												<ul class="second-sub-menu">
													<li><a href="#">Offline Classroom Programs</a></li>
													<li><a href="#">Digital Classroom Programs</a></li>
													<li><a href="#">Non-Classroom Programs</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XI</a>
												<ul class="second-sub-menu">
													<li><a href="#">Offline Classroom Programs</a></li>
													<li><a href="#">Digital Classroom Programs</a></li>
													<li><a href="#">Non-Classroom/ Correspondence Programs</a></li>
													<li><a href="#">Integrated School Program</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XII</a>
												<ul class="second-sub-menu">
													<li><a href="#">Offline Classroom Programs</a></li>
													<li><a href="#">Digital Classroom Programs</a></li>
													<li><a href="#">Non-Classroom Programs</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XII Pass</a>
												<ul class="second-sub-menu">
													<li><a href="#">Offline Classroom Programs</a></li>
													<li><a href="#">Non-Classroom Programs</a></li>
												</ul>
											</li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Competitive exams</a>
										<ul class="sub-menu">
											<li class="dropdown-holder"><a href="comp_exam.php">Class V</a>
												<ul class="second-sub-menu">
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition)</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class VI</a>
												<ul class="second-sub-menu">
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition</a></li>
													<li><a href="#">VVM (Vidyarthi Vigyan Manthan)</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest</a></li>
													<li><a href="#">DHBBVC (Dr. Homi Bhabha Balvaidnyanik Competition)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class VII</a>
												<ul class="second-sub-menu">
													<li><a href="#">Junior Science Olympiad</a></li>
													<li><a href="#">Mathematics Olympiad</a></li>
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition)</a></li>
													<li><a href="#">VVM (Vidyarthi Vigyan Manthan)</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class VIII</a>
												<ul class="second-sub-menu">
													<li><a href="#">Green Olympiad</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class IX</a>
												<ul class="second-sub-menu">
													<li><a href="#">Junior Science Olympiads - NSEJS / IOQJS, INJSO, IJSO</a></li>
													<li><a href="#">Mathematics Olympiad - PRMO / IOQM, INMO, IMO</a></li>
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition</a></li>
													<li><a href="#">VVM (Vidyarthi Vigyan Manthan</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest</a></li>
													<li><a href="#">DHBBVC (Dr. Homi Bhabha Balvaidnyanik Competition)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class X</a>
												<ul class="second-sub-menu">
													<li><a href="#">Astronomy Olympiad - NSEA / IOQA, INAO, IAO</a></li>
													<li><a href="#">Physics Olympiad - NSEP / IOQP, INPhO, IPhO</a></li>
													<li><a href="#">Biology Olympiad</a></li>
													<li><a href="#">Chemistry Olympiad - NSEC / IOQC, INChO, IChO</a></li>
													<li><a href="#">Mathematics Olympiad - PRMO / IOQM, INMO, IMO</a></li>
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition</a></li>
													<li><a href="#">VVM (Vidyarthi Vigyan Manthan)</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XI</a>
												<ul class="second-sub-menu">
													<li><a href="#">Astronomy Olympiad - NSEA / IOQA, INAO, IAO</a></li>
													<li><a href="#">Physics Olympiad - NSEP / IOQP, INPhO, IPhO</a></li>
													<li><a href="#">Chemistry Olympiad - NSEC / IOQC, INChO, IChO</a></li>
													<li><a href="#">Mathematics Olympiad - PRMO / IOQM, INMO, IMO</a></li>
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition)</a></li>
													<li><a href="#">VVM (Vidyarthi Vigyan Manthan)</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XII</a>
												<ul class="second-sub-menu">
													<li><a href="#">JEE Main</a></li>
													<li><a href="#">JEE Advanced</a></li>
													<li><a href="#">BITSAT</a></li>
													<li><a href="#">CUET (Common University Entrance Test)</a></li>
													<li><a href="#">MHT CET (Maharashtra CET)</a></li>
													<li><a href="#">Astronomy Olympiad - NSEA / IOQA, INAO, IAO</a></li>
													<li><a href="#">Physics Olympiad - NSEP / IOQP, INPhO, IPhO</a></li>
													<li><a href="#">Chemistry Olympiad - NSEC / IOQC, INChO, IChO</a></li>
													<li><a href="#">Mathematics Olympiad - PRMO / IOQM, INMO, IMO</a></li>
													<li><a href="#">Green Olympiad</a></li>
													<li><a href="#">ANMC (Aryabhatta National Maths Competition</a></li>
													<li><a href="#">NMTC (National Mathematics Talent Contest)</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Class XII Pass</a>
												<ul class="second-sub-menu">
													<li><a href="#">JEE Mai</a></li>
													<li><a href="#">JEE Advanced</a></li>
													<li><a href="#">BITSAT</a></li>
													<li><a href="#">CUET (Common University Entrance Test)</a></li>
													<li><a href="#">MHT CET (Maharashtra CET)</a></li>
												</ul>
											</li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Admission test</a>
										<ul class="sub-menu">
											<li><a href="javascript:void(0);">Pattern Proof Teaching</a></li>
											<li><a href="javascript:void(0);">Personalized Coaching</a></li>
											<li><a href="javascript:void(0);">Study Resources</a></li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Events</a>
										<ul class="sub-menu">
											<li class="dropdown-holder"><a href="event.php">Workshops</a>
												<ul class="second-sub-menu">
													<li><a href="#">Item 1</a></li>
													<li><a href="#">Item 2</a></li>
													<li><a href="#">Item 3</a></li>
													<li><a href="#">Item 4</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Camps</a>
												<ul class="second-sub-menu">
													<li><a href="#">Item 1</a></li>
													<li><a href="#">Item 2</a></li>
													<li><a href="#">Item 3</a></li>
													<li><a href="#">Item 4</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Seminars</a>
												<ul class="second-sub-menu">
													<li><a href="#">Item 1</a></li>
													<li><a href="#">Item 2</a></li>
													<li><a href="#">Item 3</a></li>
													<li><a href="#">Item 4</a></li>
												</ul>
											</li>
											<li class="dropdown-holder"><a href="#">Upcomming Admission Tests</a>
												<ul class="second-sub-menu">
													<li><a href="#">Item 1</a></li>
													<li><a href="#">Item 2</a></li>
													<li><a href="#">Item 3</a></li>
													<li><a href="#">Item 4</a></li>
												</ul>
											</li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Results</a>
										<ul class="sub-menu">
											<li><a href="javascript:void(0);">Notice-Recent Updates</a></li>
											<li><a href="javascript:void(0);">Result</a></li>
											<li><a href="javascript:void(0);">Previous Year Solution</a></li>
											<li><a href="javascript:void(0);">Time Table</a></li>
											<li><a href="javascript:void(0);">Past Results</a></li>
											<li><a href="javascript:void(0);">FAQ'S</a></li>
											<li><a href="javascript:void(0);">Syllabus</a></li>
											<li><a href="javascript:void(0);">FIITJEE Centres</a></li>
											<li><a href="javascript:void(0);">Hostels</a></li>
										</ul>
									</li>
									<li class="dropdown-holder menu-list"><a href="#" class="tran3s">Downloads</a>
										<ul class="sub-menu">
											<li><a href="javascript:void(0);">Image Gallery</a></li>
											<li><a href="javascript:void(0);">Video Gallery</a></li>
											<li><a href="javascript:void(0);">Media Gallery</a></li>
											<li><a href="javascript:void(0);">Toppers Speak</a></li>
										</ul>
									</li>
									<!-- <li><a href="javascript:void(0);" class="tran3s">Contact Us</a></li> -->
								</ul>
						   </div><!-- /.navbar-collapse -->
						</nav> <!-- /.theme-main-menu -->
					</div> <!-- /.header-wrapper -->
				</div>
			</header> <!-- /.theme-menu-wrapper -->